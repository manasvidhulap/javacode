package com.Feb20;

public class String1 {

	public static void main(String[] args) 
	{
		String name="Hello sneha";
		System.out.println(name);
		String a = new String("Good morning");
		System.out.println(a);
	}

}
