package com.factory;

public class xyzNetwork extends CellularPlan
{

	@Override
	void getRate() {
		rate=1.75;
		
	}


}
