package com.factory;

public class abcNetwork extends CellularPlan
{

	@Override
	void getRate() 
	{
		rate=1.50;
	}

}
