package com.factory;

public interface plan 
{
	void getroi(double rate);
}
