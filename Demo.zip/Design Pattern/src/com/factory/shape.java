package com.factory;

public interface shape 
{
	void  getshape(String shape);
}
