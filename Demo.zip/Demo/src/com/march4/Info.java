package com.march4;

public class Info {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String name="sneha";
		
		System.out.println(name);
	}

}
