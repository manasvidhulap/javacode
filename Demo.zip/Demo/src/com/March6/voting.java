package com.March6;

public class voting extends Exception
{
	voting(String msg)
	{
		super();
		System.out.println(msg);
	}
}
