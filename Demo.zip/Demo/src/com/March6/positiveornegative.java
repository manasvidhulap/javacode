package com.March6;

public class positiveornegative extends Exception
{
	positiveornegative(String msg)
	{
		super();
		System.out.println(msg);
	}

}
