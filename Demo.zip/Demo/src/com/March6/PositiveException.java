package com.March6;

public class PositiveException extends Exception
{
	PositiveException(String msg)
	{
		System.out.println(msg);
	}

}
