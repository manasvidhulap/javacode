package com.March6;

public class NegativeException extends Exception
{
	NegativeException(String msg)
	{
		System.out.println(msg);
	}
}
