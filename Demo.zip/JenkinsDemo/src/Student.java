
public class Student {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		String name="sneha";
		int Roll_no=120;
		
		System.out.println(name+" "+Roll_no);

	}

}
