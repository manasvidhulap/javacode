
public class Employee {

	public static void main(String[] args) 
	{
		String fname="sneha";
		String lname="Dhulap";
		System.out.println(fname+" "+lname);
	}

}
