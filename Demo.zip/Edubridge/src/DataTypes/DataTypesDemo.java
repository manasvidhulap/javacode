package DataTypes;

public class DataTypesDemo {

	public static void main(String[] args) 
	{
		String name = "sneha dhulap";
		int age = 20;
		String add = "Mankhurd";
		System.out.println("Name :"+name);
		 System.out.println("age :"+age);
		 System.out.println("add :"+add);
	}

}
