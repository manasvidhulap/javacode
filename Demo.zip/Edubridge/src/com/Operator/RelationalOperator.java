package com.Operator;

public class RelationalOperator {

	public static void main(String[] args)
	{
		System.out.println(1>=4);
		System.out.println(8<7);
		System.out.println(4==7);
		System.out.println(0!=4);
		System.out.println(27>6);
	}

}
