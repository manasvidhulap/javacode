package com.Operator;

public class LogicalOperator {

	public static void main(String[] args) 
	{
		System.out.println(4>=5 && 4==4);
		System.out.println(4>5 || 4==4);
		System.out.println(!(7==5));
	}

}
