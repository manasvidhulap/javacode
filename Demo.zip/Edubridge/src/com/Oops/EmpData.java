package com.Oops;

public class EmpData 
{
	String name = "Sneha";
	int age =20;

	public static void main(String[] args)
	{
		EmpData emp = new EmpData();
		System.out.println(emp.name+" "+emp.age);

	}

}
