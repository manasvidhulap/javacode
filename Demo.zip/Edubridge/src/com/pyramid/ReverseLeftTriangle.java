package com.pyramid;

public class ReverseLeftTriangle 
{
	public static void main(String[] args) 
	{
		int row=7;
		for(int i=row;i>=1;i--)
		{
			for(int j=row;j>=i;j--)
			{
				System.out.println(" ");
			}
			for(int k=1;k<=i;k++)
			{
				System.out.println();
			}
		}
	}

}
