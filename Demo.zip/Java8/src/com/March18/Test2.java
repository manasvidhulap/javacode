package com.March18;
interface name
{
	public void get();
}
public class Test2 {

	public static void main(String[] args) 
	{
		name n1=()->System.out.println("Sneha Dhulap Here...!!!");
		n1.get();
	}

}
