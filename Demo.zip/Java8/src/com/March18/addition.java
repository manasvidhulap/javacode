package com.March18;
interface add
{
	public void plus(int num);
}
public class addition 
{

	public static void main(String[] args) 
	{
		add a1= (int num)->System.out.println(num+num);
		a1.plus(20);
	}

}
